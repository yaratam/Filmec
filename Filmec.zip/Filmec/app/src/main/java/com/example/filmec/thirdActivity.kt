package com.example.filmec

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class thirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
    }
}